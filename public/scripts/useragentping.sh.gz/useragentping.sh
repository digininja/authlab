#!/usr/bin/env bash

echo "Pinging server to check it is up."
echo

ret=`curl -s -A "authlab desktop app" https://authlab.digi.ninja/UserAgentPing`

if [[ $ret =~ "Pong" ]]; then
	echo "The server is up"
else
	echo "The server is not up"
fi
